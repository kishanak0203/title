import { test, expect } from '@playwright/test';
import { BookstorePage } from '../pages/BookstorePage.js';

test('first book can be added to the cart', async ({ page }) => {
  const bookstore = new BookstorePage(page);
  await bookstore.signIn('kishanmasfj@gmail.com', 'kishan0203');

  const firstProductText = await bookstore.getFirstProductText();
  console.log('first product: ' + firstProductText);

  await bookstore.addFirstProductToCart();
  await bookstore.openCart();

  const cartProductText = await bookstore.getCartProductText();
  expect(cartProductText).toContain(firstProductText);
});
