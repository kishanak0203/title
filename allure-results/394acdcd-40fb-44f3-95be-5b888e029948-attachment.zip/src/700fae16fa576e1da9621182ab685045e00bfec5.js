export class BookstorePage {
  constructor(page) {
    this.page = page;
    this.emailInput = page.locator('#email');
    this.passwordInput = page.locator('#password');
    this.submitButton = page.locator('[type="submit"]');
    this.allBooksLink = page.getByRole('link', { name: 'All Books' });
    this.productTitles = page.$$('.card-title');
    this.addToCartButton = page.locator('.btn.btn-danger');
    this.cartLink = page.locator('a').filter({ has: page.locator('img[alt="Cart"]') });
    this.cartProductName = page.locator(
      '//table[contains(@class, "table")]/tbody/tr/td[2]'
    );
  }
  async signIn(email, password) {
    await this.page.goto('https://practice.expandtesting.com/bookstore/user/signin');
    await this.emailInput.fill(email);
    await this.passwordInput.fill(password);
    await this.submitButton.click();
    await this.allBooksLink.click();
  }
  async getFirstProductText() {
    return (await this.productTitles.textContent());
  }
  async addFirstProductToCart(name) {
    await this.productTitles.first().click();
    await this.addToCartButton.click();
  }
  async openCart() {
    await this.cartLink.click();
  }

  async getCartProductText() {
    return (await this.cartProductName.first().textContent());
  }
}
